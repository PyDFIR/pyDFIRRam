# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rampoetry']

package_data = \
{'': ['*']}

install_requires = \
['datetime>=5.2,<6.0',
 'graphviz>=0.20.1,<0.21.0',
 'pandas>=2.0.3,<3.0.0',
 'pyarrow>=12.0.1,<13.0.0',
 'regex>=2023.6.3,<2024.0.0',
 'typing-extensions>=4.7.1,<5.0.0',
 'volatility3>=2.4.1,<3.0.0']

setup_kwargs = {
    'name': 'rampoetry',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Objectifs du projet\n1. Faciliter la recherche et le try and retry avec volatility\n2. Parser plus facilement les outputs\n3. Se concentrer sur la data plutot que sur la commandes\n4. Utiliser comme un dataset\n5. Pouvoir gerer plusieurs dump dans un meme programme\n\n# Utilisation\n## Installation\npython3 -m venv pydfirVenv\nsource pydfirVenv/bi,/activate\ngit clone https://github.com/pyDFIR/pyDFIRRam\ncd pyDFIRRam\npoetry build\npoetry install\n\n# Differentes facon d\'utiliser\n1. Jupyter notebook\n\n```bash\npoetry run jupyter notebood\n```\n\n2. Ficher de configuration (Outil CLI)\n3. Developper directement dans un fichier \n\n# Exemples\n\n```Python\nfrom pyDFIRRam import windows\nimport os\nwinObj1 = windows(os.getcwd()+"memdump.mem") -> Les parametres ici sont tres importants voir documentations\n\ndata1 = winObj1.PsList()\ndata2 = winObj2.PsTree()\n\ndata1\ndata2\n....\n```\n\nLes fonctionnalités prises en charge sont directement dans la documentation',
    'author': 'Braguette',
    'author_email': 'alexis.debrito@ecole2600.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
